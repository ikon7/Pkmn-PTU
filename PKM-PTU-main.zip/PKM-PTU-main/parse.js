var pokemonInRoute = "Squirtle-Wartortle-Blastoise-Totodile-Croconaw-Feraligatr-Lotad-Lombre-Ludicolo-Tynamo-Eelektrik-Eelektross-Poliwag-Poliwhirl-Poliwrath-Politoed-Azurill-Marill-Azumarill-Tympole-Palpitoad-Seismitoad-Surskit-Masquerain-Croagunk-Toxicroak-Slowpoke-Slowbro-Slowking-Goldeen-Seaking-Barboach-Whiscash-Carvanha-Sharpedo-Ducklett-Swanna-Psyduck-Golduck-Wooper-Quagsire-Buizel-Floatzel-Magikarp-Gyarados-Feebas-Milotic"


var p = "Farfetchd-Stunfisk-Vaporeon-Dratini-Dragonair-Dragonite-Froakie-Frogadier-Greninja"

var p2 = "Simisage-Pansear-Simisear-Panpour-Simipour-Chatot-Dunsparce-Stantler-Audino-Spinda-Kecleon-Castform-Smeargle-Zangoose-Seviper-Shuckle-Pinsir-Heracross-Tropius-Pachirisu-Emolga-Mawile-Absol-Spiritomb-Plusle-Minun-Volbeat-Illumise-Ditto-Eevee--Vaporeon-Jolteon-Espeon-Umbreon-Leafeon-Chespin-Quilladin-Chesnaught-Fennekin-Braixen-Delphox-Bunnelby-Diggersby-Fletchling-Fletchinder-Talonflame-Scatterbug-Spewpa"

var p3 = "Vivillon-Flabébé-Floette-Florges-Skiddo-Gogoat-Pancham-Pangoro-Spritzee-Aromatisse-Hawlucha-Dedenne-Phantump-Trevenant-Pumpkaboo-Gourgeist"

var splitter = pokemonInRoute.split("-");
console.log(splitter);

var splitter2 = p.split("-");
console.log(splitter2);

// var splitter3 = pokemonInRoute.split("-");
// console.log(splitter3);

// var splitter4 = p.split("-");
// console.log(splitter4);

